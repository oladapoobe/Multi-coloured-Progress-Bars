var content1 = document.getElementById("content1");
var content2 = document.getElementById("content2");
var content3 = document.getElementById("content3");
var content4 = document.getElementById("content4");
var content5 = document.getElementById("content5");
 
content1.textContent="50%"
    content2.textContent="50%"
    content3.textContent="50%"
    content4.textContent="50%"
    content5.textContent="50%"

$(".meter > span").each(function () {
  $(this)
    .data("origWidth", $(this).width())
    .width(0)
    .animate(
      {
        width: $(this).data("origWidth")
      },
      1200
    );
});



var btn = document.getElementById("btn");
btn.addEventListener("click", function() {
    content1.style.width = "100%";
     content2.style.width = "100%";
     content3.style.width = "100%";
     content4.style.width = "100%";
     content5.style.width = "100%";
  content1.textContent="100%"
    content2.textContent="100%"
    content3.textContent="100%"
    content4.textContent="100%"
    content5.textContent="100%"
});